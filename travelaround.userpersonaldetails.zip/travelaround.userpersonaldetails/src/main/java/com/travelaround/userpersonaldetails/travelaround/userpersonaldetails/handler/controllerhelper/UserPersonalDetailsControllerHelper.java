package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.handler.controllerhelper;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.response.UserPersonalDetailsResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class UserPersonalDetailsControllerHelper {

    public static ResponseEntity<UserPersonalDetailsResponse> getUserPersonalDetailsResponseResponseEntity(UserPersonalDetailsResponse userPersonalDetailsResponse) {
        return userPersonalDetailsResponse.getUserPersonalDetailsDto() != null ?
                new ResponseEntity<>(userPersonalDetailsResponse, HttpStatus.OK) :
                ResponseEntity.notFound().build();
    }
}
