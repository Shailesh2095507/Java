package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.response;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.dto.UserPersonalDetailsDto;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UserPersonalDetailsResponse {

    private UserPersonalDetailsDto userPersonalDetailsDto;

    private List<UserPersonalDetailsDto> userPersonalDetailsDtoList;

    private String message;

    public UserPersonalDetailsDto getUserPersonalDetailsDto() {
        return userPersonalDetailsDto;
    }

    public void setUserPersonalDetailsDto(UserPersonalDetailsDto userPersonalDetailsDto) {
        this.userPersonalDetailsDto = userPersonalDetailsDto;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<UserPersonalDetailsDto> getUserPersonalDetailsDtoList() {
        return userPersonalDetailsDtoList;
    }

    public void setUserPersonalDetailsDtoList(List<UserPersonalDetailsDto> userPersonalDetailsDtoList) {
        this.userPersonalDetailsDtoList = userPersonalDetailsDtoList;
    }
}
