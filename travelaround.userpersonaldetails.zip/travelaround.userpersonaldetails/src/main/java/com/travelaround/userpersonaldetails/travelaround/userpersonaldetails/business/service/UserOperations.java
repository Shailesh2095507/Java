package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.business.service;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.request.UserPersonalDetailsRequest;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.response.UserPersonalDetailsResponse;
import org.springframework.stereotype.Service;

@Service
public interface UserOperations {

    public UserPersonalDetailsResponse saveUserDetails(UserPersonalDetailsRequest userPersonalDetailsRequest);

    public UserPersonalDetailsResponse updateUserDetails(UserPersonalDetailsRequest userPersonalDetailsRequest);

    public UserPersonalDetailsResponse getUserPersonalDetailsById(UserPersonalDetailsRequest userPersonalDetailsRequest);

    public UserPersonalDetailsResponse deleteUserPersonalDetailsById(UserPersonalDetailsRequest userPersonalDetailsRequest);

    public UserPersonalDetailsResponse getAllUserPersonalDetails();

    public UserPersonalDetailsResponse deleteAllUserPersonalDetails();
}
