package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.converter.dtotoentity;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.dto.UserPersonalDetailsDto;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.embeddedable.UserAddress;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.embeddedable.UserName;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.entity.UserPersonalDetails;
import org.springframework.stereotype.Component;

@Component
public class UserPersonalDetailsDtoToEntityConverter {

    public UserPersonalDetails setUserPersonalDetailsDtoToEntity(UserPersonalDetailsDto userPersonalDetailsDto) {
        UserPersonalDetails userPersonalDetails = new UserPersonalDetails();
        userPersonalDetails.setUserId(userPersonalDetailsDto.getUserId());

        UserName userName = setUserNameToEntity(userPersonalDetailsDto);
        userPersonalDetails.setUserName(userName);

        UserAddress userAddress = setUserAddressToEntity(userPersonalDetailsDto);
        userPersonalDetails.setUserAddress(userAddress);

        userPersonalDetails.setUserDateOfBirth(userPersonalDetailsDto.getDateOfBirth());
        userPersonalDetails.setPhoneNumber(userPersonalDetailsDto.getPhoneNumber());
        userPersonalDetails.setEmailId(userPersonalDetailsDto.getEmailId());
        userPersonalDetails.setUserCitizenship(userPersonalDetailsDto.getCitizenship());

        return userPersonalDetails;
    }

    private UserAddress setUserAddressToEntity(UserPersonalDetailsDto userPersonalDetailsDto) {
        UserAddress userAddress = new UserAddress();
        userAddress.setHouseNumber(userPersonalDetailsDto.getHouseNumber());
        userAddress.setStreet(userPersonalDetailsDto.getStreet());
        userAddress.setArea(userPersonalDetailsDto.getArea());
        userAddress.setCity(userPersonalDetailsDto.getCity());
        userAddress.setState(userPersonalDetailsDto.getState());
        userAddress.setCountry(userPersonalDetailsDto.getCountry());
        return userAddress;
    }

    private UserName setUserNameToEntity(UserPersonalDetailsDto userPersonalDetailsDto) {
        UserName userName = new UserName();
        userName.setFirstName(userPersonalDetailsDto.getFirstName());
        userName.setMiddleName(userPersonalDetailsDto.getMiddleName());
        userName.setLastName(userPersonalDetailsDto.getLastName());
        return userName;
    }

}
