package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.constants;

public enum CustomHttpStatus {
    SUCCESS(200, "SUCCESS");

    private final int value;
    private final String reasonPhrase;

    CustomHttpStatus(int value, String reasonPhrase) {
        this.value = value;
        this.reasonPhrase = reasonPhrase;
    }

    public int value() {
        return this.value;
    }

    public String getReasonPhrase() {
        return reasonPhrase;
    }

}
