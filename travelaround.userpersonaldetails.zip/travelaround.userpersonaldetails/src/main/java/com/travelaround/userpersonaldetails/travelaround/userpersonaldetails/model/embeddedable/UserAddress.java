package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.embeddedable;

import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Embeddable
public class UserAddress {

    @NotNull(message = "houseNumber Cannot be null")
    @Size(min = 1)
    private String houseNumber;

    @NotNull(message = "street Cannot be null")
    @Size(min = 1)
    private String street;

    @NotNull(message = "area Cannot be null")
    @Size(min = 4)
    private String area;

    @NotNull(message = "city Cannot be null")
    @Size(min = 4)
    private String city;

    @NotNull(message = "state Cannot be null")
    @Size(min = 3)
    private String state;

    @NotNull(message = "country Cannot be null")
    @Size(min = 3)
    private String country;

    public String getHouseNumber() {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber) {
        this.houseNumber = houseNumber;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "UserAddress{" +
                "houseNumber='" + houseNumber + '\'' +
                ", street='" + street + '\'' +
                ", area='" + area + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}
