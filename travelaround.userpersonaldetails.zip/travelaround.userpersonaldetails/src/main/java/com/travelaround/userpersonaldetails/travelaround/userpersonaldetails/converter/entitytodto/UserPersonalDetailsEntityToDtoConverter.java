
package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.converter.entitytodto;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.dto.UserPersonalDetailsDto;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.entity.UserPersonalDetails;
import org.springframework.stereotype.Component;

@Component
public class UserPersonalDetailsEntityToDtoConverter {

    public UserPersonalDetailsDto setUserUserPersonalDetailsToDto(UserPersonalDetails userPersonalDetails) {
        UserPersonalDetailsDto userPersonalDetailsDto = new UserPersonalDetailsDto();

        userPersonalDetailsDto.setUserId(userPersonalDetails.getUserId());
        userPersonalDetailsDto.setFirstName(userPersonalDetails.getUserName().getFirstName());
        userPersonalDetailsDto.setMiddleName(userPersonalDetails.getUserName().getMiddleName());
        userPersonalDetailsDto.setLastName(userPersonalDetails.getUserName().getLastName());

        userPersonalDetailsDto.setHouseNumber(userPersonalDetails.getUserAddress().getHouseNumber());
        userPersonalDetailsDto.setStreet(userPersonalDetails.getUserAddress().getStreet());
        userPersonalDetailsDto.setArea(userPersonalDetails.getUserAddress().getArea());
        userPersonalDetailsDto.setCity(userPersonalDetails.getUserAddress().getCity());
        userPersonalDetailsDto.setState(userPersonalDetails.getUserAddress().getState());
        userPersonalDetailsDto.setCountry(userPersonalDetails.getUserAddress().getCountry());

        userPersonalDetailsDto.setDateOfBirth(userPersonalDetails.getUserDateOfBirth());
        userPersonalDetailsDto.setPhoneNumber(userPersonalDetails.getPhoneNumber());
        userPersonalDetailsDto.setEmailId(userPersonalDetails.getEmailId());
        userPersonalDetailsDto.setCitizenship(userPersonalDetails.getUserCitizenship());
        return userPersonalDetailsDto;
    }

}
