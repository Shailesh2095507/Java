package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.entity;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.embeddedable.UserAddress;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.embeddedable.UserName;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.hibernate.validator.constraints.UniqueElements;

import java.util.Date;

@Entity
@Table(name = "user_personal_details")
public class UserPersonalDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @NotNull(message = "userName Cannot be null")
    private UserName userName;

    @NotNull(message = "userAddress Cannot be null")
    private UserAddress userAddress;

    @NotNull(message = "userDateOfBirth Cannot be null")
    private Date userDateOfBirth;

    @NotNull(message = "userCitizenship Cannot be null")
    @Size(min = 2, max = 50)
    private String userCitizenship;

    @NotNull(message = "phoneNumber Cannot be null")
    @Digits(integer = 10, fraction = 0)
    private Long phoneNumber;

    @NotNull(message = "emailId Cannot be null")
    @Size(min = 10, max = 70)
    private String emailId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public UserName getUserName() {
        return userName;
    }

    public void setUserName(UserName userName) {
        this.userName = userName;
    }

    public UserAddress getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(UserAddress userAddress) {
        this.userAddress = userAddress;
    }

    public Date getUserDateOfBirth() {
        return userDateOfBirth;
    }

    public void setUserDateOfBirth(Date userDateOfBirth) {
        this.userDateOfBirth = userDateOfBirth;
    }

    public String getUserCitizenship() {
        return userCitizenship;
    }

    public void setUserCitizenship(String userCitizenship) {
        this.userCitizenship = userCitizenship;
    }

    public Long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

}