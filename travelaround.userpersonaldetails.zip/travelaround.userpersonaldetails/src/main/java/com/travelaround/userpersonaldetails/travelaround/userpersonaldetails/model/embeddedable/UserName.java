package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.embeddedable;

import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Embeddable
public class UserName {

    @NotNull(message = "firstName Cannot be null")
    @Size(min = 4, max = 50, message = "First-name cannot exceed more than 50 chars")
    private String firstName;

    @Size(min = 0, max = 50, message = "Middle-name cannot exceed more than 50 chars")
    private String middleName;

    @NotNull(message = "lastName Cannot be null")
    @Size(min = 1, max = 50, message = "Last-name cannot exceed more than 50 chars")
    private String lastName;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return "UserName{" +
                "firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }
}
