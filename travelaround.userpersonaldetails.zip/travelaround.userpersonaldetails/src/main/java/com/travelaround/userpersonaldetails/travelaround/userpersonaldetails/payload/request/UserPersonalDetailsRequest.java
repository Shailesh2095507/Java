package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.request;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.dto.UserPersonalDetailsDto;
import org.springframework.stereotype.Component;

@Component
public class UserPersonalDetailsRequest {

    private UserPersonalDetailsDto userPersonalDetailsDto;

    public UserPersonalDetailsDto getUserPersonalDetailsDto() {
        return userPersonalDetailsDto;
    }

    public void setUserPersonalDetailsDto(UserPersonalDetailsDto userPersonalDetailsDto) {
        this.userPersonalDetailsDto = userPersonalDetailsDto;
    }

}
