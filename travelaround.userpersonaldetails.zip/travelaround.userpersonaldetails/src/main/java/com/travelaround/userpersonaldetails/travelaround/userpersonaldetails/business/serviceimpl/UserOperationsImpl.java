package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.business.serviceimpl;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.business.repository.UserPersonalDetailsRepository;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.business.service.UserOperations;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.business.serviceimplextender.UserOperationsImplExtender;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.dto.UserPersonalDetailsDto;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.entity.UserPersonalDetails;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.request.UserPersonalDetailsRequest;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.response.UserPersonalDetailsResponse;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserOperationsImpl implements UserOperations {

    private static final String SAVE_USER_DETAILS = "User Personal Details Saved Successfully !";

    private static final String DELETE_USER_DETAILS = "User Personal Details Deleted Successfully !";

    private static final String DELETE_ALL_USER_DETAILS = " All User Personal Details Deleted Successfully !";

    private static final String ENTITY_NOT_FOUND_EXCEPTION = "UserPersonalDetails not found for id:";

    @Autowired
    private UserPersonalDetailsRepository userPersonalDetailsRepository;

    @Autowired
    private UserOperationsImplExtender userOperationsImplExtender;

    @Override
    public UserPersonalDetailsResponse saveUserDetails(UserPersonalDetailsRequest userPersonalDetailsRequest) {
        if (userPersonalDetailsRequest != null && userPersonalDetailsRequest.getUserPersonalDetailsDto() != null) {
            UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
            UserPersonalDetailsDto userPersonalDetailsDto = userPersonalDetailsRequest.getUserPersonalDetailsDto();
            UserPersonalDetails userPersonalDetails = userOperationsImplExtender.setUserPersonalDetails(userPersonalDetailsDto);
            userPersonalDetailsRepository.save(userPersonalDetails);

            Long savedUserId = userPersonalDetails.getUserId();

            Optional<UserPersonalDetails> userPersonalDetailsOptional = savedUserId != null ?
                    userPersonalDetailsRepository.findById(savedUserId) :
                    Optional.empty();

            UserPersonalDetails userPersonalDetail = userPersonalDetailsOptional.orElseThrow(() ->
            {
                return new EntityNotFoundException(ENTITY_NOT_FOUND_EXCEPTION + savedUserId);
            });

            UserPersonalDetailsDto updatedUserPersonalDetailsDto = userOperationsImplExtender.setUserPersonalDetailsDto(userPersonalDetail);
            userPersonalDetailsResponse.setUserPersonalDetailsDto(updatedUserPersonalDetailsDto);
            userPersonalDetailsResponse.setMessage(SAVE_USER_DETAILS);
            return userPersonalDetailsResponse;
        }
        return new UserPersonalDetailsResponse();
    }

    @Override
    public UserPersonalDetailsResponse updateUserDetails(UserPersonalDetailsRequest userPersonalDetailsRequest) {
        if (userPersonalDetailsRequest != null && userPersonalDetailsRequest.getUserPersonalDetailsDto() != null) {
            UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
            UserPersonalDetailsDto userPersonalDetailsDto = userPersonalDetailsRequest.getUserPersonalDetailsDto();

            Optional<UserPersonalDetails> userPersonalDetailsOptional = userPersonalDetailsDto != null ?
                    userPersonalDetailsRepository.findById(userPersonalDetailsDto.getUserId()) :
                    Optional.empty();

            UserPersonalDetails userPersonalDetails = userPersonalDetailsOptional.orElseThrow(() ->
            {
                assert userPersonalDetailsDto != null;
                return new EntityNotFoundException(ENTITY_NOT_FOUND_EXCEPTION + userPersonalDetailsDto.getUserId());
            });

            if (userPersonalDetails != null &&
                    userPersonalDetails.getUserId().equals(userPersonalDetailsDto.getUserId()) &&
                    userPersonalDetails.getUserDateOfBirth().equals(userPersonalDetailsDto.getDateOfBirth())) {
                UserPersonalDetails updatedUserPersonalDetails = userOperationsImplExtender.setUserPersonalDetails(userPersonalDetailsDto);
                userPersonalDetailsRepository.save(updatedUserPersonalDetails);
                userPersonalDetailsResponse.setUserPersonalDetailsDto(userOperationsImplExtender.setUserPersonalDetailsDto(updatedUserPersonalDetails));
                return userPersonalDetailsResponse;
            }
            assert userPersonalDetails != null;
            userPersonalDetailsResponse.setUserPersonalDetailsDto(userOperationsImplExtender.setUserPersonalDetailsDto(userPersonalDetails));
            return userPersonalDetailsResponse;
        }
        return new UserPersonalDetailsResponse();
    }

    @Override
    public UserPersonalDetailsResponse getUserPersonalDetailsById(UserPersonalDetailsRequest userPersonalDetailsRequest) {
        if (userPersonalDetailsRequest.getUserPersonalDetailsDto().getUserId() != null) {
            UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
            Long userId = userPersonalDetailsRequest.getUserPersonalDetailsDto().getUserId();
            Optional<UserPersonalDetails> optionalUserPersonalDetails = userPersonalDetailsRepository.findById(userId);
            UserPersonalDetails userPersonalDetails = optionalUserPersonalDetails.orElseThrow(() ->
                    new EntityNotFoundException(ENTITY_NOT_FOUND_EXCEPTION + userId));
            userPersonalDetailsResponse.setUserPersonalDetailsDto(userOperationsImplExtender.setUserPersonalDetailsDto(userPersonalDetails));
            return userPersonalDetailsResponse;
        }
        return new UserPersonalDetailsResponse();
    }

    @Override
    public UserPersonalDetailsResponse deleteUserPersonalDetailsById(UserPersonalDetailsRequest userPersonalDetailsRequest) {
        UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
        userPersonalDetailsRepository.deleteById(userPersonalDetailsRequest.getUserPersonalDetailsDto().getUserId());
        userPersonalDetailsResponse.setMessage(DELETE_USER_DETAILS);
        return userPersonalDetailsResponse;
    }

    @Override
    public UserPersonalDetailsResponse getAllUserPersonalDetails() {
        UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
        List<UserPersonalDetails> userPersonalDetailsList = userPersonalDetailsRepository.findAll();

        List<UserPersonalDetailsDto> userPersonalDetailsDtoList = new ArrayList<>();


        if (!userPersonalDetailsList.isEmpty()) {
            for (UserPersonalDetails userPersonalDetails : userPersonalDetailsList) {
                userPersonalDetailsDtoList.add(userOperationsImplExtender.setUserPersonalDetailsDto(userPersonalDetails));
            }
            userPersonalDetailsResponse.setUserPersonalDetailsDtoList(userPersonalDetailsDtoList);
        }
        userPersonalDetailsResponse.setUserPersonalDetailsDtoList(userPersonalDetailsDtoList);
        return userPersonalDetailsResponse;
    }

    @Override
    public UserPersonalDetailsResponse deleteAllUserPersonalDetails() {
        UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
        userPersonalDetailsRepository.deleteAll();
        userPersonalDetailsResponse.setMessage(DELETE_ALL_USER_DETAILS);

        List<UserPersonalDetails> userPersonalDetailsList = userPersonalDetailsRepository.findAll();
        List<UserPersonalDetailsDto> userPersonalDetailsDtoList = new ArrayList<>();

        if (!userPersonalDetailsList.isEmpty()) {
            for (UserPersonalDetails userPersonalDetails : userPersonalDetailsList) {
                userPersonalDetailsDtoList.add(userOperationsImplExtender.setUserPersonalDetailsDto(userPersonalDetails));
            }
            userPersonalDetailsResponse.setUserPersonalDetailsDtoList(userPersonalDetailsDtoList);
        }
        userPersonalDetailsResponse.setUserPersonalDetailsDtoList(userPersonalDetailsDtoList);
        return userPersonalDetailsResponse;
    }
}

