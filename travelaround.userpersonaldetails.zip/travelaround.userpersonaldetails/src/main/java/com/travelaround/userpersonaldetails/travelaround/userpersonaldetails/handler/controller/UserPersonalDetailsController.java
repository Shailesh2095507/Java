package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.handler.controller;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.business.service.UserOperations;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.handler.controllerhelper.UserPersonalDetailsControllerHelper;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.request.UserPersonalDetailsRequest;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.payload.response.UserPersonalDetailsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "api/userRegistration")
public class UserPersonalDetailsController {

    private static final String SAVE_USER_DETAILS = "User Personal Details Saved Successfully !";

    private static final String DELETE_USER_DETAILS = "User Personal Details Deleted Successfully !";

    private static final String DELETE_ALL_USER_DETAILS = " All User Personal Details Deleted Successfully !";

    @Autowired
    private UserOperations userOperations;

    @PostMapping(value = "/saveUserDetails")
    public ResponseEntity<UserPersonalDetailsResponse> saveUserDetails(@RequestBody UserPersonalDetailsRequest userPersonalDetailsRequest) {
        UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
        if (userPersonalDetailsRequest != null) {
            userPersonalDetailsResponse = userOperations.saveUserDetails(userPersonalDetailsRequest);
        }
        return (userPersonalDetailsResponse.getMessage().equals(SAVE_USER_DETAILS)) ?
                new ResponseEntity<>(userPersonalDetailsResponse, HttpStatus.OK) :
                ResponseEntity.badRequest().build();
    }

    @PutMapping(value = "/updateUserDetails")
    public ResponseEntity<UserPersonalDetailsResponse> updateUserDetails(@RequestBody UserPersonalDetailsRequest userPersonalDetailsRequest) {
        UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
        if (userPersonalDetailsRequest != null && userPersonalDetailsRequest.getUserPersonalDetailsDto().getUserId() != null) {
            userPersonalDetailsResponse = userOperations.updateUserDetails(userPersonalDetailsRequest);
        }
        return UserPersonalDetailsControllerHelper.getUserPersonalDetailsResponseResponseEntity(userPersonalDetailsResponse);
    }

    @GetMapping(value = "/getUserPersonalDetailsById")
    public ResponseEntity<UserPersonalDetailsResponse> getUserPersonalDetailsById(@RequestBody UserPersonalDetailsRequest userPersonalDetailsRequest) {
        UserPersonalDetailsResponse userPersonalDetailsResponse = new UserPersonalDetailsResponse();
        if (userPersonalDetailsRequest != null && userPersonalDetailsRequest.getUserPersonalDetailsDto().getUserId() != null) {
            userPersonalDetailsResponse = userOperations.getUserPersonalDetailsById(userPersonalDetailsRequest);
        }
        return UserPersonalDetailsControllerHelper.getUserPersonalDetailsResponseResponseEntity(userPersonalDetailsResponse);
    }

    @DeleteMapping(value = "/deleteUserPersonalDetailsById")
    public ResponseEntity<UserPersonalDetailsResponse> deleteUserPersonalDetailsById(@RequestBody UserPersonalDetailsRequest userPersonalDetailsRequest) {
        if (userPersonalDetailsRequest != null && userPersonalDetailsRequest.getUserPersonalDetailsDto().getUserId() != null) {
            UserPersonalDetailsResponse userPersonalDetailsResponse = userOperations.deleteUserPersonalDetailsById(userPersonalDetailsRequest);
            if (!userPersonalDetailsResponse.getMessage().equals(DELETE_USER_DETAILS)) {
                return UserPersonalDetailsControllerHelper.getUserPersonalDetailsResponseResponseEntity(userPersonalDetailsResponse);
            }
        }
        return ResponseEntity.badRequest().build();
    }

    @GetMapping(value = "/getAllUserPersonalDetails")

    public ResponseEntity<UserPersonalDetailsResponse> getAllUserPersonalDetails() {
        UserPersonalDetailsResponse userPersonalDetailsResponse = userOperations.getAllUserPersonalDetails();
        return userPersonalDetailsResponse.getUserPersonalDetailsDtoList().isEmpty() ? ResponseEntity.notFound().build() :
                new ResponseEntity<>(userPersonalDetailsResponse, HttpStatus.OK);
    }

    @DeleteMapping("/deleteAllUserPersonalDetails")
    public ResponseEntity<UserPersonalDetailsResponse> deleteAllUserPersonalDetails() {
        UserPersonalDetailsResponse userPersonalDetailsResponse = userOperations.deleteAllUserPersonalDetails();
        return (userPersonalDetailsResponse.getMessage().equals(DELETE_ALL_USER_DETAILS)
                && userPersonalDetailsResponse.getUserPersonalDetailsDtoList().isEmpty()) ?
                new ResponseEntity<>(userPersonalDetailsResponse, HttpStatus.OK) :
                ResponseEntity.badRequest().build();
    }

}
