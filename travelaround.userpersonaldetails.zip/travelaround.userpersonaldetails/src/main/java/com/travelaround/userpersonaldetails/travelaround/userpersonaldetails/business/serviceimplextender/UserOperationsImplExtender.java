package com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.business.serviceimplextender;

import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.converter.dtotoentity.UserPersonalDetailsDtoToEntityConverter;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.converter.entitytodto.UserPersonalDetailsEntityToDtoConverter;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.dto.UserPersonalDetailsDto;
import com.travelaround.userpersonaldetails.travelaround.userpersonaldetails.model.entity.UserPersonalDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserOperationsImplExtender {

    @Autowired
    private UserPersonalDetailsEntityToDtoConverter userPersonalDetailsEntityToDtoConverter;

    @Autowired
    private UserPersonalDetailsDtoToEntityConverter userPersonalDetailsDtoToEntityConverter;

    public UserPersonalDetails setUserPersonalDetails(UserPersonalDetailsDto userPersonalDetailsDto) {
        return userPersonalDetailsDtoToEntityConverter.setUserPersonalDetailsDtoToEntity(userPersonalDetailsDto);
    }

    public UserPersonalDetailsDto setUserPersonalDetailsDto(UserPersonalDetails userPersonalDetails) {
        return userPersonalDetailsEntityToDtoConverter.setUserUserPersonalDetailsToDto(userPersonalDetails);
    }
}
