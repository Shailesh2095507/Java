package dev.shailesh.movies.service;

import dev.shailesh.movies.pojo.Movie;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface MovieService {

    public List<Movie> getAllMovies();

    public Optional<Movie> getMovieByImdbId(String imdbId);
}
