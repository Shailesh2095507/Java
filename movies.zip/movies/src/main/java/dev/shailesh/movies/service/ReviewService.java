package dev.shailesh.movies.service;

import dev.shailesh.movies.pojo.Movie;
import dev.shailesh.movies.pojo.Review;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface ReviewService {

    public Review postAReview(String reviewBody, String imdbId);
}
