package com.springdemo.dependencyInjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class School {
    @Bean
    public Student student() {
        return new Student();
    }

    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(School.class);
        
        Student sc1 = context.getBean(Student.class);
        Student sc2 = context.getBean(Student.class);
        
        System.out.println("sc1: " + sc1);
        System.out.println("sc2: " + sc2);
    }
}