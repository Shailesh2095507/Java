package com.springdemo.dependencyInjection;

import org.springframework.stereotype.Component;

@Component
public class Teacher implements PersonalInfo {
    @Override
    public void getName() {
        System.out.println("Prof Shailesh C");
    }

    @Override
    public String getDOB() {
        System.out.println("25-08-1999");
        return null;
    }
}
