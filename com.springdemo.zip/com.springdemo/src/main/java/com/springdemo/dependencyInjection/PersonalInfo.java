package com.springdemo.dependencyInjection;

import org.springframework.stereotype.Service;

@Service
public interface PersonalInfo {
	
    public void getName();

    public String getDOB();
}
