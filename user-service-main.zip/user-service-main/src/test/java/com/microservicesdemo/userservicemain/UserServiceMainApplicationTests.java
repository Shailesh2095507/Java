package com.microservicesdemo.userservicemain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceMainApplicationTests {

	@Test
	void contextLoads() {
	}

}
