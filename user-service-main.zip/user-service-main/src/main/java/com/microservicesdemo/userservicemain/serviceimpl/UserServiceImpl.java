package com.microservicesdemo.userservicemain.serviceimpl;

import com.microservicesdemo.userservicemain.dtos.DepartmentDTO;
import com.microservicesdemo.userservicemain.dtos.ResponseDTO;
import com.microservicesdemo.userservicemain.dtos.UserDTO;
import com.microservicesdemo.userservicemain.entity.User;
import com.microservicesdemo.userservicemain.repository.UserRepository;
import com.microservicesdemo.userservicemain.service.UserService;
import com.microservicesdemo.userservicemain.serviceimpl.serviceimplextender.UserServiceImplExtender;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private UserServiceImplExtender userServiceImplExtender;

    @Override
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public ResponseDTO getUser(Long userId) {

        ResponseDTO responseDTO = new ResponseDTO();
        User user = userRepository.findById(userId).get();

        UserDTO userDTO = userServiceImplExtender.mapToUser(user);

        ResponseEntity<DepartmentDTO> departmentDTOResponseEntity =
                restTemplate.getForEntity("http://localhost:8080/api/departments/" + user.getDepartmentId(),
                        DepartmentDTO.class);

        DepartmentDTO departmentDTO = departmentDTOResponseEntity.getBody();

        responseDTO.setUserDTO(userDTO);
        responseDTO.setDepartmentDTO(departmentDTO);

        return responseDTO;
    }
}
