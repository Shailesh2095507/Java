package com.microservicesdemo.userservicemain.serviceimpl.serviceimplextender;

import com.microservicesdemo.userservicemain.dtos.UserDTO;
import com.microservicesdemo.userservicemain.entity.User;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImplExtender {

    public UserDTO mapToUser(User user){
        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        userDTO.setFirstName(user.getFirstName());
        userDTO.setLastName(user.getLastName());
        userDTO.setEmail(user.getEmail());
        return userDTO;
    }
}
