package com.microservicesdemo.userservicemain.controller;

import com.microservicesdemo.userservicemain.dtos.ResponseDTO;
import com.microservicesdemo.userservicemain.entity.User;
import com.microservicesdemo.userservicemain.service.UserService;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "api/users")
@NoArgsConstructor
@AllArgsConstructor
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<User> saveUser(@RequestBody User user){
        User saveUser = userService.saveUser(user);
        return new ResponseEntity<>(saveUser, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<ResponseDTO> getUser(@PathVariable("id") Long userId){
        ResponseDTO responseDTO = userService.getUser(userId);
        return new ResponseEntity<>(responseDTO,HttpStatus.OK);
    }
}
