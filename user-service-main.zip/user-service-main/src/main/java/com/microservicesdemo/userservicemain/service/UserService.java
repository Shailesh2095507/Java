package com.microservicesdemo.userservicemain.service;

import com.microservicesdemo.userservicemain.dtos.ResponseDTO;
import com.microservicesdemo.userservicemain.entity.User;
import org.springframework.stereotype.Service;

@Service
public interface UserService {

    public User saveUser(User user);

    public ResponseDTO getUser(Long userId);
}
