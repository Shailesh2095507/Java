package com.microservicesdemo.userservicemain.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class DepartmentDTO {

    private Long id;
    private String departmentName;
    private String departmentAddress;
    private String departmentCode;
}
