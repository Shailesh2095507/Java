package com.example.spring.withoutspringboot.SpringWithoutSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWithoutSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
