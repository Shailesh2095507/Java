package com.example.spring.withoutspringboot.SpringWithoutSpringBoot;

import com.example.spring.withoutspringboot.SpringWithoutSpringBoot.basic.BinarySearchImpl;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class SpringWithoutSpringBootApplication {

	public static void main(String[] args) {

		try(ConfigurableApplicationContext applicationContext =
				new AnnotationConfigApplicationContext(SpringWithoutSpringBootApplication.class)) {

			BinarySearchImpl binarySearch1 = applicationContext.getBean(BinarySearchImpl.class);
			int result = binarySearch1.binarySearch(new int[]{1, 2, 3}, 3);
			System.out.println("Object : " + binarySearch1 + " Result : " + result);
		}
	}

}
