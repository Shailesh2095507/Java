package com.example.spring.withoutspringboot.SpringWithoutSpringBoot.basic;

public interface SortAlgorithm {

    public int[] sort(int[] numbers);
}
