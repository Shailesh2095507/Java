package com.example.spring.withoutspringboot.SpringWithoutSpringBoot.basic;

import org.springframework.stereotype.Component;

@Component
public class BubbleSortAlgorithm implements SortAlgorithm {
    public int[] sort(int[] numbers)
    {
        //sort logic
        return numbers;
    }
}
