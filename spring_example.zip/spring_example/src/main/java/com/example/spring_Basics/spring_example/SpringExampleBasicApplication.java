package com.example.spring_Basics.spring_example;

import com.example.spring_Basics.spring_example.basic.BinarySearchImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

//SpringBoot will automatically search for the beans.
@SpringBootApplication // it typically scans for the packages and the sub-packages that they are in.
public class SpringExampleBasicApplication {

	public static void main(String[] args) {

		// This is handled by Spring Framework.
		//BinarySearchImpl binarySearch = new BinarySearchImpl(new BubbleSortAlgorithm());

		ConfigurableApplicationContext applicationContext = SpringApplication.run(SpringExampleBasicApplication.class, args);
		BinarySearchImpl binarySearch = applicationContext.getBean(BinarySearchImpl.class);
		int result = binarySearch.binarySearch(new int[] {1,2,3},3);
		System.out.println("Object : " + binarySearch +" Result : "+ result);

	}

}
