package com.example.spring_Basics.spring_example.basic;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BinarySearchImpl {
    //    sort an array
    //    search the array for an element
    //    return the result

    private static final Logger LOGGER = LoggerFactory.getLogger(BinarySearchImpl.class);

    @Autowired
    SortAlgorithm sortAlgorithm;

    public int binarySearch(int[] numbers , int numberToSearchFor)
    {
        int[] sortedNumbers =  sortAlgorithm.sort(numbers);
        return 3;
    }

    @PostConstruct
    public void postConstruct(){
        LOGGER.info("Post Construct");
    }

    @PreDestroy
    public void preDestroy(){
        LOGGER.info("Pre Destroy");
    }
}
