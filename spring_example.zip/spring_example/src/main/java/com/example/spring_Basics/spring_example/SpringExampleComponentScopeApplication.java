package com.example.spring_Basics.spring_example;

import com.example.spring_Basics.componentScan.scope.ComponentDAO;
import com.example.spring_Basics.spring_example.scope.PersonDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

//SpringBoot will automatically search for the beans.
@SpringBootApplication // it typically scans for the packages and the sub-packages that they are in.
@ComponentScan("com.example.spring_Basics.componentScan") // when we are looking for a bean of a different package.
public class SpringExampleComponentScopeApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(SpringExampleComponentScopeApplication.class);

	public static void main(String[] args) {

		ConfigurableApplicationContext applicationContext = SpringApplication.run(SpringExampleComponentScopeApplication.class, args);

		ComponentDAO componentDAO = applicationContext.getBean(ComponentDAO.class);

		LOGGER.info("{}", componentDAO);
		LOGGER.info("{}", componentDAO.getJdbcConnection());

	}

}
