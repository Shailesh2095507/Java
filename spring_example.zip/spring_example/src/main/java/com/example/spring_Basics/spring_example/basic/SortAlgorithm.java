package com.example.spring_Basics.spring_example.basic;

public interface SortAlgorithm {

    public int[] sort(int[] numbers);
}
