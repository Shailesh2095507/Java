package com.example.spring_Basics.spring_example.xml;

// when we need different instances of dependency instead bean itself, use proxy

public class XmlJdbcConnection {

    public XmlJdbcConnection() {
        System.out.println("JDBC Connection");
    }

}
