package com.example.spring_Basics.spring_example;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.spring_Basics.spring_example.xml.XmlPersonDAO;

public class SpringExampleXMLContextApplication {

	public static void main(String[] args) {

	try(ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml")) {
		XmlPersonDAO personDAO = applicationContext.getBean(XmlPersonDAO.class);

		System.out.println(personDAO);
		System.out.println(personDAO.getXmlJdbcConnection());
		}
	}
}
