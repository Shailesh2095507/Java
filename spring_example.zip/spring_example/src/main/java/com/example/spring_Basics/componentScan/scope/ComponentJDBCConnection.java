package com.example.spring_Basics.componentScan.scope;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

// when we need different instances of dependency instead bean itself, use proxy
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ComponentJDBCConnection {

    public ComponentJDBCConnection() {
        System.out.println("JDBC Connection");
    }

}
