package com.in28minutes.login;

import org.springframework.stereotype.Service;

@Service
public class UserValidationService {
	
	public boolean isUserValid(String user, String password) 
	{
		if(user.equals("Shailesh") && password.equals("Shata")) 
		{
			return true;
		}
		return false;
	}

}
