package com.microservicesdemo.departmentservicemain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentServiceMainApplicationTests {

	@Test
	void contextLoads() {
	}

}
