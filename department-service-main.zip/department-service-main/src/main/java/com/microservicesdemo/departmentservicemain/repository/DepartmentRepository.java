package com.microservicesdemo.departmentservicemain.repository;

import com.microservicesdemo.departmentservicemain.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department,Long> {
}
