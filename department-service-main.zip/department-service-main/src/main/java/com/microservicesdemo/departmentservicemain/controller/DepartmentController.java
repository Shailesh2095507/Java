package com.microservicesdemo.departmentservicemain.controller;

import com.microservicesdemo.departmentservicemain.entity.Department;
import com.microservicesdemo.departmentservicemain.service.DepartmentService;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "api/departments")
@AllArgsConstructor
@NoArgsConstructor
public class DepartmentController {
    @Autowired
    private DepartmentService departmentService;

    @PostMapping
    public ResponseEntity<Department> saveDepartment(@RequestBody Department department) {
        Department saveDepartment = departmentService.saveDepartment(department);
        return new ResponseEntity<>(saveDepartment, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<Department> getDepartmentById(@PathVariable("id") Long departmentId){
    Department getDepartmentById = departmentService.getDepartment(departmentId);
    return new ResponseEntity<>(getDepartmentById,HttpStatus.OK);
    }
}

