package com.microservicesdemo.departmentservicemain.service;

import com.microservicesdemo.departmentservicemain.DepartmentServiceMainApplication;
import com.microservicesdemo.departmentservicemain.entity.Department;
import org.springframework.stereotype.Service;

@Service
public interface DepartmentService {
    public Department saveDepartment(Department department);

    public  Department getDepartment(Long departmentId);
}
